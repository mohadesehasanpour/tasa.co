
document.getElementById("root").innerHTML = `<h1>لطفاً این پروژه را با ابزارهایی مثل Vite, React, یا Next.js اجرا کنید.</h1><p>فایلی که آپلود شده JSX است و مستقیم توسط مرورگر اجرا نمی‌شود.</p>`;
