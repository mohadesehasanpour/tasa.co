import { useState } from "react";
import { Button } from "@/components/ui/button";

export default function TASAWebsite() {
  const [lang, setLang] = useState("fa");

  const content = {
    fa: {
      title: "شرکت توسعه افق سپهر آینده (TASA)",
      subtitle: "راهکارهای هوشمند برای نگهداری و مدیریت تأسیسات",
      about: `TASA یک شرکت نوآور در حوزه مدیریت مجتمع‌های ساختمانی و نگهداری تأسیسات است. با بهره‌گیری از فناوری‌هایی مانند Digital Twin، تیم تخصصی، و ساختار علمی، خدماتی جامع، پایدار و حرفه‌ای ارائه می‌دهد.`,
      services: [
        "مدیریت جامع تأسیسات و نگهداری پیشگیرانه",
        "پیاده‌سازی سیستم‌های هوشمند (Digital Twin)",
        "افزایش بهره‌وری و کاهش هزینه‌های عملیاتی",
        "مستندسازی فنی و تحلیل داده برای تصمیم‌سازی",
        "تیم فنی آموزش‌دیده و پشتیبانی ۲۴/۷"
      ],
      contact: "تماس با ما"
    },
    en: {
      title: "Tose'e Ofogh Sepehr Ayandeh (TASA)",
      subtitle: "Smart solutions for facilities maintenance & management",
      about: `TASA is an innovative company specializing in facility management and maintenance of commercial complexes. By utilizing technologies like Digital Twin, expert teams, and a scientific approach, it delivers sustainable, integrated, and professional services.`,
      services: [
        "Comprehensive facility management & preventive maintenance",
        "Implementation of smart systems (Digital Twin)",
        "Efficiency improvement & operational cost reduction",
        "Technical documentation and data-driven decision support",
        "Trained technical teams and 24/7 support"
      ],
      contact: "Contact Us"
    },
    ar: {
      title: "شركة تطوير أفق سَپِهر المستقبل (TASA)",
      subtitle: "حلول ذكية لصيانة وإدارة المنشآت",
      about: `TASA هي شركة مبتكرة متخصصة في إدارة وصيانة المجمعات التجارية. باستخدام تقنيات مثل التوأم الرقمي (Digital Twin) وفِرَق متخصصة ونهج علمي، تقدم خدمات شاملة ومستدامة ومهنية.`,
      services: [
        "إدارة شاملة وصيانة وقائية للمنشآت",
        "تنفيذ أنظمة ذكية (التوأم الرقمي)",
        "تحسين الكفاءة وتقليل التكاليف التشغيلية",
        "توثيق فني وتحليل البيانات لاتخاذ القرار",
        "فِرَق تقنية مدربة ودعم على مدار الساعة"
      ],
      contact: "اتصل بنا"
    }
  };

  return (
    <div className="p-6 max-w-3xl mx-auto text-center">
      <div className="flex justify-end gap-2 mb-4">
        <Button onClick={() => setLang("fa")}>FA</Button>
        <Button onClick={() => setLang("en")}>EN</Button>
        <Button onClick={() => setLang("ar")}>AR</Button>
      </div>
      <h1 className="text-3xl font-bold mb-2">{content[lang].title}</h1>
      <p className="text-lg text-gray-700 mb-6">{content[lang].subtitle}</p>
      <p className="text-base text-gray-600 mb-6">{content[lang].about}</p>
      <ul className="text-left mb-6">
        {content[lang].services.map((s, i) => (
          <li key={i} className="mb-2">✅ {s}</li>
        ))}
      </ul>
      <Button className="bg-[#1C2C4C] text-white hover:bg-[#334766]">
        {content[lang].contact}
      </Button>
    </div>
  );
}